from flask import Flask, render_template, request, redirect, session, url_for, flash, jsonify
from flask_pymongo import PyMongo
from flask_bcrypt import Bcrypt
from dotenv import load_dotenv
import os
import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from google import genai 
import json
from bson.objectid import ObjectId

# 1. Load environment variables
load_dotenv()

app = Flask(__name__)

# 2. Configuration
app.config["MONGO_URI"] = os.getenv("MONGO_URI")
app.secret_key = os.getenv("SECRET_KEY")

# 3. Initialize Extensions
mongo = PyMongo(app)
bcrypt = Bcrypt(app)

# 4. Configure Gemini AI
try:
    client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
except Exception as e:
    print(f"⚠️ Warning: Gemini API Key issue: {e}")

# --- HELPER: GENERIC AI JSON PARSER ---
def get_gemini_json(prompt):
    try:
        import re
        import json
        import os
        from google import genai

        api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if not api_key:
            print("AI Setup Error: No API key found in .env file!")
            return None

        client = genai.Client(api_key=api_key)

        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt
        )

        text = response.text.strip()

        # -------------------------------
        # STEP 1: Remove markdown blocks
        # -------------------------------
        text = re.sub(r"```json|```", "", text).strip()

        # -------------------------------
        # STEP 2: Extract all JSON objects
        # -------------------------------
        json_objects = re.findall(r'\{.*?\}', text, re.DOTALL)

        if not json_objects:
            print("Error: No JSON objects found in AI response.")
            print("Raw Output:\n", text)
            return None

        # -------------------------------
        # STEP 3: Convert to valid JSON
        # -------------------------------
        if len(json_objects) == 1:
            # Single object
            return json.loads(json_objects[0])
        else:
            # Multiple objects → wrap as array
            json_array_string = "[" + ",".join(json_objects) + "]"
            return json.loads(json_array_string)

    except json.JSONDecodeError as e:
        print(f"AI JSON Error: {e}")
        print("Raw AI Output was:\n", text)
        return None

    except Exception as e:
        print(f"AI General Error: {e}")
        return None


# --- HELPER: SPECIFIC PLACE SEARCH ---
def get_ai_places(query, location_context):
    """
    Specific helper to ask Gemini for a LIST of places (for Search/Essentials).
    """
    prompt = f"""
    I am a tourist in {location_context['city']}, {location_context['country']} (Lat: {location_context['lat']}, Lng: {location_context['lng']}).
    I am looking for: "{query}".
    
    Please act as a real-time travel engine. 
    1. Identify 5 REAL, specific places that match this request near the city center.
    2. Provide an estimated Latitude and Longitude for each (essential for mapping).
    3. Provide a 1-sentence helpful description/tip for a tourist.
    4. Provide a "Gemini Suggestion" summary (1 sentence) about this category in this city.

    Return STRICT JSON format only:
    {{
        "suggestion": "Tip about this category...",
        "places": [
            {{
                "name": "Name of Place",
                "type": "Category (e.g. Cafe)",
                "price": "$$ or Free",
                "rating": "4.5",
                "address": "Street name or area",
                "description": "Why go here...",
                "lat": 12.345, 
                "lng": 67.890
            }}
        ]
    }}
    """
    return get_gemini_json(prompt) or {"suggestion": "AI could not fetch results.", "places": []}

# --- EMAIL FUNCTION ---
def send_email(recipient, subject, body):
    sender_email = os.getenv("GMAIL_EMAIL")
    sender_password = os.getenv("GMAIL_APP_PASSWORD")

    print(f"📧 Sending email to: {recipient}")

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.text = msg.as_string()
        server.sendmail(sender_email, recipient, msg.as_string())
        server.quit()
        print("✅ Email sent successfully!")
        return True
    except Exception as e:
        print(f"❌ Email Error: {e}")
        return False

# --- ROUTES ---

@app.route('/')
def index():
    # 🔴 FORCE START AT LOGIN PAGE
    session.clear()
    return redirect(url_for('login'))

# --- AUTHENTICATION ROUTES ---

@app.route('/register', methods=['GET'])
def register_page():
    return render_template('auth/register.html')

@app.route('/send-otp', methods=['POST'])
def send_otp():
    full_name = request.form.get('full_name')
    email = request.form.get('email')
    password = request.form.get('password')

    if mongo.db.users.find_one({'email': email}):
        flash('Email already registered. Please login.', 'danger')
        return redirect(url_for('login'))

    otp = random.randint(1000, 9999)
    session['otp'] = otp
    session['otp_email'] = email
    session['pending_user'] = {
        'full_name': full_name,
        'email': email,
        'password': bcrypt.generate_password_hash(password).decode('utf-8')
    }

    email_body = f"Hello {full_name},\n\nYour verification code is: {otp}\n\nWelcome to CityPal!"
    if send_email(email, "Your Verification Code", email_body):
        flash('OTP sent to your email!', 'info')
        return redirect(url_for('verify_otp_page'))
    else:
        flash('Failed to send email. Check credentials.', 'danger')
        return redirect(url_for('register_page'))

@app.route('/verify-otp', methods=['GET'])
def verify_otp_page():
    if 'otp' not in session:
        return redirect(url_for('register_page'))
    return render_template('auth/verify_otp.html')

@app.route('/verify-otp', methods=['POST'])
def verify_otp():
    user_otp = request.form.get('otp')
    
    if int(user_otp) == session.get('otp'):
        pending_user = session.get('pending_user')
        mongo.db.users.insert_one({
            'full_name': pending_user['full_name'],
            'email': pending_user['email'],
            'password': pending_user['password'],
            'created_at': datetime.utcnow(),
            'current_destination': None
        })
        session.pop('otp', None)
        session.pop('pending_user', None)
        flash('Account created successfully! Please login.', 'success')
        return redirect(url_for('login'))
    else:
        flash('Invalid OTP. Please try again.', 'danger')
        return redirect(url_for('verify_otp_page'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = mongo.db.users.find_one({'email': email})

        if user and bcrypt.check_password_hash(user['password'], password):
            session['user_email'] = user['email']
            session['user_id'] = str(user['_id'])
            
            if user.get('current_destination'):
                session['current_destination'] = user['current_destination']
                return redirect(url_for('home'))
            
            flash('Login successful!', 'success')
            return redirect(url_for('set_destination'))
        else:
            flash('Invalid email or password', 'danger')

    return render_template('auth/login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# --- ONBOARDING ROUTES ---

@app.route('/set-destination')
def set_destination():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('onboarding/set_destination.html')

@app.route('/api/search-destinations', methods=['POST'])
def search_destinations():
    data = request.json
    query = data.get('query')
    
    prompt = f"""
    Suggest 5 real cities that match or start with '{query}'.
    Return strictly a JSON array. Each object must have:
    - "city": City Name
    - "country": Country Name
    - "lat": Latitude (float)
    - "lng": Longitude (float)
    
    Example output format:
    [{{"city": "Paris", "country": "France", "lat": 48.85, "lng": 2.35}}]
    """
    
    cities = get_gemini_json(prompt)
    return jsonify(cities or [])

@app.route('/save-destination', methods=['POST'])
def save_destination():
    if 'user_id' not in session:
        return jsonify({"error": "Unauthorized"}), 401
    
    data = request.json
    
    # --- NEW: Fetch Currency Symbol via Gemini before saving ---
    city = data.get('city', 'Unknown')
    country = data.get('country', 'Unknown')
    
    prompt = f"""
    What is the local currency symbol for {city}, {country}? 
    Return STRICT JSON format exactly like this: {{"symbol": "€"}}
    Do not include text, just the JSON.
    """
    
    try:
        # Assuming you have your get_gemini_json function available here
        ai_data = get_gemini_json(prompt)
        symbol = ai_data.get('symbol', '$') if ai_data else '$'
    except Exception as e:
        print("Error fetching currency:", e)
        symbol = '$'
        
    # Add the symbol to the data dictionary
    data['currency_symbol'] = symbol
    # ---------------------------------------------------------
    
    # Save to session
    session['current_destination'] = data
    
    # Save to MongoDB
    mongo.db.users.update_one(
        {'_id': ObjectId(session['user_id'])},
        {'$set': {'current_destination': data}}
    )
    
    return jsonify({"status": "success", "currency_symbol": symbol})

# --- HOME PAGE ---

@app.route('/home')
def home():
    if 'user_id' not in session: 
        return redirect(url_for('login'))
        
    dest = session.get('current_destination')
    
    # --- NEW: Dynamic Currency Fetch via Gemini ---
    if dest and 'currency_symbol' not in dest:
        city = dest.get('city', 'Unknown')
        country = dest.get('country', 'Unknown')
        
        # Ask Gemini for the currency symbol
        prompt = f"""
        What is the local currency symbol for {city}, {country}? 
        Return STRICT JSON format exactly like this: {{"symbol": "€"}}
        Do not include text, just the JSON.
        """
        
        try:
            ai_data = get_gemini_json(prompt)
            # Default to '$' if Gemini fails
            symbol = ai_data.get('symbol', '$') if ai_data else '$'
        except Exception as e:
            print("Error fetching currency:", e)
            symbol = '$'
            
        # Save it to the session so we don't ask Gemini on every page reload
        dest['currency_symbol'] = symbol
        session['current_destination'] = dest
        session.modified = True
    # ----------------------------------------------

    return render_template('home/index.html', destination=dest)

# --- SEARCH & ESSENTIALS (UPDATED FOR NAVIGATION) ---

# --- UPDATE THIS ROUTE IN app.py ---

# --- UPDATE IN app.py ---

@app.route('/search', methods=['GET'])
def search_handler():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    query = request.args.get('query')
    destination = session.get('current_destination', {})
    is_navigate = request.args.get('navigate') 
    
    # 1. Get Coordinates
    lat_param = request.args.get('lat')
    lng_param = request.args.get('lng')
    try:
        user_lat = float(lat_param) if lat_param else 0.0
        user_lng = float(lng_param) if lng_param else 0.0
    except ValueError:
        user_lat, user_lng = 0.0, 0.0

    # 2. GET FILTER INPUTS 
    # Default to 5km and 5000 if not set
    max_dist = request.args.get('filter_dist', '5')
    max_price = request.args.get('filter_price', '5000')

    if not query:
        return redirect(url_for('home'))

    # --- NEW: Get the dynamic currency symbol from the session ---
    # Defaulting to '$' just in case it wasn't set properly
    currency_symbol = destination.get('currency_symbol', '$')

    # 3. AI Logic
    if is_navigate == 'true':
        # (Navigation Prompt remains unchanged)
        prompt = f"""
        Find the exact location of '{query}' in {destination.get('city')}.
        Return JSON: {{
            "suggestion": "Navigation route found.",
            "places": [{{
                "name": "{query}",
                "type": "Destination",
                "price": "-",
                "rating": "4.5",
                "address": "Local Address in {destination.get('city')}",
                "description": "Navigating to destination...",
                "lat": 0.0, 
                "lng": 0.0
            }}]
        }}
        """
        ai_data = get_gemini_json(prompt)
    else:
        # 4. UPDATED STANDARD SEARCH PROMPT (With Filters & Dynamic Currency)
        prompt = f"""
        Act as a local guide for {destination.get('city')}, {destination.get('country')}.
        User Query: "{query}"

        FILTERS TO APPLY:
        - Search Radius: Strictly within {max_dist} km of the city center (or user location).
        - Price Budget: Approx {currency_symbol}{max_price} or less.

        Task: Find 5 best places matching the query and filters.
        
        CRITICAL INSTRUCTIONS:
        1. List 5 REAL, EXISTING places.
        2. Provide ACCURATE Latitude/Longitude for mapping.
        3. If no places perfectly match the budget, show the closest options.
        4. PRICE FORMAT: Return a specific estimated cost using the exact local currency symbol ({currency_symbol}) (e.g., "{currency_symbol}200", "{currency_symbol}1500"). Do NOT use symbols like "$$" unless the local currency is actually "$".
        
        Return STRICT JSON:
        {{
            "suggestion": "Found top results for '{query}' within {max_dist}km.",
            "places": [
                {{
                    "name": "Example Place",
                    "rating": "4.5",
                    "type": "Category",
                    "price": "{currency_symbol}400 approx",
                    "address": "Street Name, Area",
                    "description": "Short description...",
                    "lat": 11.93,
                    "lng": 79.83
                }}
            ]
        }}
        """
        ai_data = get_gemini_json(prompt)
    
    # 5. Render Template
    return render_template('home/results.html', 
                           category=query.title(), 
                           query=query, 
                           destination=destination,
                           places=ai_data.get('places', []) if ai_data else [],
                           ai_suggestion=ai_data.get('suggestion') if ai_data else "Results found via Gemini",
                           user_lat=user_lat,
                           user_lng=user_lng,
                           current_loc_name=""
                           )
# --- UPDATE IN app.py ---

# --- UPDATE IN app.py ---

# --- UPDATE IN app.py ---

# --- UPDATE IN app.py ---

# --- UPDATE IN app.py ---

@app.route('/essentials/<category>')
def essentials_search(category):
    if 'user_id' not in session: return redirect(url_for('login'))
    
    dest = session.get('current_destination')
    
    # 1. Get Coordinates (Critical for Map to work without crashing)
    # We default to 0.0 if not provided, just like the Search route
    lat_param = request.args.get('lat')
    lng_param = request.args.get('lng')
    try:
        user_lat = float(lat_param) if lat_param else 0.0
        user_lng = float(lng_param) if lng_param else 0.0
    except ValueError:
        user_lat, user_lng = 0.0, 0.0

    print(f"\n📍 ESSENTIALS SEARCH: {category} in {dest['city']}")

    # 2. AI Logic (Same structure as Search)
    prompt = f"""
    Act as a local guide for {dest['city']}, {dest['country']}.
    I am looking for the top 5 BEST "{category}" places in {dest['city']}.

    CRITICAL INSTRUCTIONS:
    1. List 5 REAL, POPULAR existing places.
    2. Provide ACCURATE Latitude/Longitude for mapping.
    3. Do not return empty.
    4. PRICE FORMAT: Return a specific estimated cost in local currency (e.g., "₹200", "₹1500"), NOT symbols like "$$".
    
    Return STRICT JSON:
    {{
        "suggestion": "Here are the top rated {category} spots in {dest['city']}.",
        "places": [
            {{
                "name": "Example Place Name",
                "rating": "4.5",
                "type": "{category}",
                "price": "₹400 approx",
                "address": "Street Name, Area",
                "description": "Short description of why it's popular.",
                "lat": 11.931,
                "lng": 79.835
            }}
        ]
    }}
    """
    
    ai_data = get_gemini_json(prompt)
    
    # 3. Safe Data Extraction
    places_list = []
    suggestion = ""
    if ai_data:
        places_list = ai_data.get('places', [])
        suggestion = ai_data.get('suggestion', '')
        print(f"✅ Served {len(places_list)} results.")
    else:
        print("⚠️ AI returned None. Serving empty list.")

    # 4. Render Template (Passing ALL variables needed by results.html)
    return render_template('home/results.html', 
                           category=category.title(), 
                           query=category,
                           places=places_list, 
                           destination=dest,
                           ai_suggestion=suggestion,
                           user_lat=user_lat,       # CRITICAL: Fixes "flyToPlace not defined" error
                           user_lng=user_lng,       # CRITICAL: Fixes "flyToPlace not defined" error
                           current_loc_name=""
                           )
# --- AIRPORT ROUTES ---

@app.route('/airport')
def airport_hub():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    dest = session.get('current_destination')
    if not dest: return redirect(url_for('set_destination'))
    
    # Ask AI for the nearest main airport to the current destination
    prompt = f"""
    What is the main international airport serving {dest['city']}, {dest['country']}?
    Return JSON: {{ 
        "name": "Airport Name", 
        "code": "IATA Code", 
        "lat": 0.0, 
        "lng": 0.0, 
        "distance": "15km" 
    }}
    """
    airport_data = get_gemini_json(prompt)
    
    # Save to session so we can reuse details in the guides
    session['current_airport'] = airport_data
    
    return render_template('airport/hub.html', destination=dest, airport=airport_data)

@app.route('/airport/guide/<guide_type>')
def airport_guide(guide_type):
    if 'user_id' not in session: return redirect(url_for('login'))
    
    airport = session.get('current_airport')
    if not airport: return redirect(url_for('airport_hub'))
    
    # Check if this is a Do's and Don'ts request (handled by specific route, but just in case)
    if guide_type == 'airport_dos_and_donts':
        return redirect(url_for('airport_dos_donts'))

    # 1. Define the EXACT steps requested
    if guide_type == 'arrival':
        required_steps = [
            "Flight Arrival",
            "Immigration Check",
            "Baggage Claim",
            "Customs Check",
            "Exit Arrival Hall",
            "Transport"
        ]
    else: # departure
        required_steps = [
            "Enter Departure Terminal",
            "Check-in",
            "Security Checking",
            "Immigration",
            "Exit Check",
            "Duty Free and Waiting Area",
            "Boarding Gate"
        ]

    # 2. Ask AI to fill in details for THESE specific steps
    prompt = f"""
    I need a guide for {airport['name']} for the '{guide_type}' process.
    
    Please provide details for EXACTLY these steps in this order:
    {json.dumps(required_steps)}
    
    For each step, provide:
    1. "description": A short, helpful explanation (2-3 sentences HTML format).
    2. "keep_ready": A list of items/documents to have in hand (e.g. Passport, Boarding Pass).
    
    Return STRICT JSON Array matching the order above: 
    [
        {{ "title": "Step Name", "description": "...", "keep_ready": ["Item 1", "Item 2"] }}
    ]
    """
    
    steps_data = get_gemini_json(prompt)
    
    # Fallback if AI fails: use the headers with empty descriptions
    if not steps_data or len(steps_data) != len(required_steps):
        steps_data = [{"title": step, "description": "Proceed to this area.", "keep_ready": []} for step in required_steps]

    return render_template('airport/guide.html', 
                           airport_name=airport['name'], 
                           guide_type=guide_type, 
                           steps=steps_data)

@app.route('/airport/guide/preparation')
def airport_preparation():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    dest = session.get('current_destination')
    if not dest: return redirect(url_for('home'))

    # 1. Fetch User's Saved Checklist
    user = mongo.db.users.find_one({'_id': ObjectId(session['user_id'])})
    saved_data = user.get('checklist_progress', {})

    # 2. "Erase" Logic: Check if saved data matches CURRENT destination
    if saved_data.get('city') != dest['city']:
        completed_items = []
    else:
        completed_items = saved_data.get('items', [])

    return render_template('airport/preparation.html', 
                           destination=dest, 
                           completed_items=completed_items)

@app.route('/api/update-checklist', methods=['POST'])
def update_checklist():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    
    data = request.json
    dest = session.get('current_destination')
    
    mongo.db.users.update_one(
        {'_id': ObjectId(session['user_id'])},
        {'$set': {
            'checklist_progress': {
                'city': dest['city'],  
                'items': data.get('items', [])
            }
        }}
    )
    return jsonify({"status": "success"})

@app.route('/airport/guide/airport_dos_and_donts')
def airport_dos_donts():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    airport = session.get('current_airport')
    if not airport: return redirect(url_for('airport_hub'))
    
    prompt = f"""
    Provide 5 specific "Do's" and 5 "Don'ts" for travelers specifically inside {airport['name']}.
    Focus on behavior, security rules, facilities, or cultural norms inside this specific airport.
    
    Return STRICT JSON:
    {{
        "dos": [
            {{ "title": "Use the Onsen Bath", "description": "There is a public bath in the terminal perfect for relaxing." }},
            {{ "title": "Keep Passport Ready", "description": "You need it at 3 different checkpoints." }}
        ],
        "donts": [
            {{ "title": "Don't sleep in T1", "description": "It closes at night, move to T3." }},
            {{ "title": "Don't tip staff", "description": "It is considered rude in this country." }}
        ]
    }}
    """
    data = get_gemini_json(prompt)
    if not data: data = {"dos": [], "donts": []}

    return render_template('airport/dos_and_donts.html', 
                           airport_name=airport['name'], 
                           dos=data.get('dos', []), 
                           donts=data.get('donts', []))

# --- NEW: TRANSPORT ROUTES (ADDED) ---

# --- TRANSPORT CARD ROUTES ---


@app.route('/transport/<card_type>')
def transport_card_details(card_type):
    """
    PAGE 2: Details & Map for specific card type (ic-cards / qr-pass)
    """
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # Get User Location
    try:
        user_lat = float(request.args.get('lat', 0.0))
        user_lng = float(request.args.get('lng', 0.0))
    except ValueError:
        user_lat, user_lng = 0.0, 0.0

    # Determine Card Type Name for Prompt
    type_name = "Rechargeable IC Transport Card" if card_type == 'ic-cards' else "Digital QR Day Pass for Transport"

    print(f"\n🎫 FETCHING TRANSPORT CARD: {type_name} in {dest['city']}...")

    # Strict API Prompt for Real-Time Data
    prompt = f"""
    You are a Transport Data API.
    Context: User is in {dest['city']}, {dest['country']}.
    Request: Info on **{type_name}** for tourists.

    INSTRUCTIONS:
    1. Identify the specific card name used in {dest['city']} (e.g., Suica in Tokyo, Oyster in London, Navigo in Paris).
    2. Identify 3 REAL physical locations to buy/recharge this card.
       - Look for "Metro Station Ticket Office", "Convenience Store", or "Airport Transport Desk".
    3. Generate accurate Lat/Lng for these locations.

    OUTPUT FORMAT (Raw JSON only):
    {{
        "card_name": "Name of the Card (e.g. Suica)",
        "price": "Cost (e.g. 500 JPY deposit)",
        "validity": "Validity period (e.g. 10 years)",
        "benefits": ["Benefit 1", "Benefit 2"],
        "locations": [
            {{
                "name": "Station/Store Name",
                "type": "Ticket Office",
                "address": "Address in {dest['city']}",
                "lat": 12.3456,
                "lng": 78.9101
            }}
        ]
    }}
    """
    
    data = get_gemini_json(prompt)
    
    # Fallback if AI fails
    card_info = data if data else {
        "card_name": "Standard Transport Card",
        "price": "Varies", 
        "validity": "-",
        "benefits": ["Cashless travel"],
        "locations": []
    }

    return render_template('transport/card_details.html', 
                           card_type=card_type,
                           info=card_info,
                           places=card_info.get('locations', []),
                           destination=dest,
                           user_lat=user_lat,
                           user_lng=user_lng)
# --- ADD THIS TO app.py ---

@app.route('/transport/qr-pass')
def transport_qr_pass():
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # Prompt specifically for Digital/QR Tickets
    prompt = f"""
    Analyze digital public transport passes, QR code tickets, and mobile day passes for {dest['city']}, {dest['country']}.
    
    1. Identify top 3 digital/QR ticket options (e.g. Mobile Day Pass, Subway 24h Ticket, App-based tickets).
       For each provide:
       - Name
       - Validity (e.g. "24 Hours", "1 Day")
       - Price (e.g. "~$5", "~800 Yen")
       - Description (Short summary of what it covers)
    
    2. List 3 "Where to buy/download" (e.g. Official Metro App, Third-party apps like Klook).
    3. Provide 1 specific "Pro Tip" regarding scanning or offline usage.

    Return STRICT JSON:
    {{
        "passes": [
            {{
                "name": "Tokyo Subway Ticket",
                "validity": "24/48/72 Hours",
                "price": "800-1500 JPY",
                "description": "Unlimited rides on all Tokyo Metro and Toei Subway lines."
            }}
        ],
        "apps": ["Tokyo Metro App", "Klook", "Japan Travel Navitime"],
        "pro_tip": "Take a screenshot of your QR code in case you lose internet connection underground."
    }}
    """
    data = get_gemini_json(prompt)
    
    # Fallback
    if not data:
        data = {"passes": [], "apps": [], "pro_tip": "No digital pass info found."}

    return render_template('transport/qr_pass.html', destination=dest, data=data)

@app.route('/transport/taxi-apps')
def transport_taxi_apps():
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # Updated Prompt: Removed request for URL (we will build it ourselves)
    prompt = f"""
    Identify the top 3 Taxi/Ride-hailing apps used in {dest['city']}, {dest['country']} (e.g. Uber, Grab, GoJek, Rapido, Ola, Lyft).
    
    For each app, provide:
    1. Name (Just the app name, e.g. "Uber")
    2. Short Description (e.g. "Best for quick bike rides")

    Return STRICT JSON:
    {{
        "apps": [
            {{
                "name": "App Name",
                "description": "Short description..."
            }}
        ]
    }}
    """
    data = get_gemini_json(prompt)
    
    # Fallback
    if not data:
        data = {"apps": []}

    return render_template('transport/taxi_apps.html', destination=dest, apps=data.get('apps', []))

# --- ADD THIS TO app.py ---

@app.route('/currency/exchange')
def currency_exchange():
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # Prompt: Get Local Currency Code and its rate against 1 USD
    prompt = f"""
    Provide financial advice for a tourist in {dest['city']}, {dest['country']}.
    
    1. Local Currency Code (e.g. "JPY", "INR", "EUR").
    2. Exact Exchange Rate: How much is 1 USD worth in local currency? (Return JUST the number, e.g. 150.5).
    3. "Cash Advice": Is cash needed?
    4. "Card Advice": acceptance level?
    5. "ATM Advice": Best withdrawal spots?
    6. "Pro Tip": Money saving tip.

    Return STRICT JSON:
    {{
        "currency_code": "JPY",
        "usd_rate": 150.50, 
        "cash_advice": "Essential for small shops.",
        "card_advice": "Accepted in major hotels.",
        "atm_advice": "Use 7-Eleven ATMs.",
        "pro_tip": "Always pay in local currency on card machines."
    }}
    """
    data = get_gemini_json(prompt)
    
    # Fallback
    if not data:
        data = {
            "currency_code": "USD", 
            "usd_rate": 1.0, 
            "cash_advice": "Info unavailable.", 
            "card_advice": "Info unavailable.",
            "atm_advice": "Use bank ATMs.",
            "pro_tip": "Keep small change."
        }

    return render_template('currency/exchange.html', destination=dest, data=data)

# --- ADD THIS TO app.py ---

@app.route('/api/estimate-ride', methods=['POST'])
def estimate_ride_api():
    if 'user_id' not in session: 
        return jsonify({"error": "Unauthorized"}), 401
        
    data = request.json
    pickup = data.get('pickup')
    dropoff = data.get('dropoff')
    
    # 1. Get destination and currency symbol from session
    dest = session.get('current_destination', {})
    city = dest.get('city', 'Unknown')
    country = dest.get('country', 'Unknown')
    currency_symbol = dest.get('currency_symbol', '$')

    # 2. Add currency instruction to the prompt
    prompt = f"""
    Act as a local transport estimator for {city}, {country}.
    Estimate ride costs from '{pickup}' to '{dropoff}'.
    
    CRITICAL INSTRUCTION FOR PRICE:
    You MUST use the local currency symbol ({currency_symbol}) for all prices.
    Example formats: "{currency_symbol}150 - {currency_symbol}200", "{currency_symbol}50".
    Do NOT use '₹' unless the local currency is actually Indian Rupees.
    
    Return STRICT JSON in this exact format:
    {{
        "pickup": {{"lat": 11.93, "lng": 79.83}},
        "dropoff": {{"lat": 11.95, "lng": 79.85}},
        "recommendation": {{
            "app_name": "Uber/Local App Name",
            "price": "{currency_symbol}150",
            "ride_type": "Economy / Auto",
            "link_query": "uber",
            "reason": "Best balance of price and availability."
        }},
        "rides": [
            {{"type": "Standard Taxi", "time": "15 min", "price": "{currency_symbol}200", "icon": "taxi"}},
            {{"type": "Auto Rickshaw", "time": "18 min", "price": "{currency_symbol}80", "icon": "motorcycle"}}
        ]
    }}
    """
    
    try:
        ai_data = get_gemini_json(prompt)
        return jsonify(ai_data if ai_data else {"error": "Failed to fetch estimates."})
    except Exception as e:
        print("Ride Estimate Error:", e)
        return jsonify({"error": "Failed to process request"}), 500
# --- ADD THIS TO app.py ---

@app.route('/guide/dos-and-donts')
def city_dos_donts():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    dest = session.get('current_destination')
    if not dest: return redirect(url_for('home'))
    
    # Prompt specific to CITY Etiquette (not Airport)
    prompt = f"""
    Provide 5 specific "Do's" and 5 "Don'ts" for a tourist visiting {dest['city']}, {dest['country']}.
    Focus on cultural etiquette, safety, local laws, and social norms (e.g. dress codes, tipping, photography, gestures).
    
    Return STRICT JSON:
    {{
        "dos": [
            {{ "title": "Dress Modestly", "description": "Cover shoulders and knees when visiting temples or holy sites." }},
            {{ "title": "Remove Shoes", "description": "Always take off shoes before entering a home or place of worship." }}
        ],
        "donts": [
            {{ "title": "Don't drink tap water", "description": "It is not safe to drink; stick to bottled or filtered water." }},
            {{ "title": "Don't touch heads", "description": "The head is considered sacred in this culture; avoid touching it." }}
        ]
    }}
    """
    data = get_gemini_json(prompt)
    
    # Fallback
    if not data:
        data = {"dos": [], "donts": []}

    return render_template('home/dos_and_donts.html', 
                           destination=dest, 
                           dos=data.get('dos', []), 
                           donts=data.get('donts', []))

# --- EMERGENCY ROUTES ---

@app.route('/emergency')
def emergency_hub():
    if 'user_id' not in session: return redirect(url_for('login'))
    return render_template('emergency/hub.html')

@app.route('/emergency/contacts')
def emergency_contacts():
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # Ask AI for local emergency numbers
    prompt = f"""
    I am in {dest['city']}, {dest['country']}.
    Provide the exact Emergency Phone Numbers for:
    1. Police
    2. Ambulance / Fire
    3. Tourist Helpline (if available)
    4. Roadside Assistance (if available)
    
    Return STRICT JSON:
    {{
        "contacts": [
            {{ "title": "Police", "number": "100" }},
            {{ "title": "Ambulance", "number": "108" }}
        ]
    }}
    """
    data = get_gemini_json(prompt)
    return render_template('emergency/contacts.html', contacts=data.get('contacts', []))

@app.route('/emergency/embassy')
def emergency_embassy():
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # Ask AI for Embassy details (Assuming Indian Embassy based on your sketch)
    prompt = f"""
    Find the 'Indian Embassy' or 'Consulate General of India' serving {dest['city']}, {dest['country']}.
    
    Provide:
    1. Description (Services provided)
    2. Full Address
    3. Exact Latitude and Longitude (for map)
    4. Phone Number
    5. Email Address
    6. Official Website URL
    
    Return STRICT JSON:
    {{
        "description": "Provides consular services...",
        "address": "123 Embassy Row...",
        "lat": 12.34,
        "lng": 56.78,
        "phone": "+1-234-567-890",
        "email": "consulate@example.com",
        "website": "https://www.indianembassy.gov.in"
    }}
    """
    data = get_gemini_json(prompt)
    if not data: data = {} # Prevent crash
    
    return render_template('emergency/embassy.html', embassy=data)

# --- ADD THIS TO app.py ---

# --- UPDATE IN app.py ---

# --- UPDATE IN app.py ---

# --- UPDATE IN app.py ---



# --- UPDATE IN app.py ---

import math

def calculate_distance(lat1, lon1, lat2, lon2):
    if not lat1 or not lon1 or not lat2 or not lon2: return 9999 # Fail safe
    R = 6371  # Earth radius in km
    dLat = math.radians(lat2 - lat1)
    dLon = math.radians(lon2 - lon1)
    a = math.sin(dLat/2) * math.sin(dLat/2) + \
        math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * \
        math.sin(dLon/2) * math.sin(dLon/2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

@app.route('/emergency/nearby')
def emergency_nearby():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    category = request.args.get('type')
    
    # Inputs can come from GPS (lat/lng) OR Manual Text (loc_name)
    lat_param = request.args.get('lat')
    lng_param = request.args.get('lng')
    loc_name = request.args.get('loc_name', '')

    user_lat = float(lat_param) if lat_param else 0.0
    user_lng = float(lng_param) if lng_param else 0.0
    
    dest = session.get('current_destination')
    
    # LOGIC:
    # 1. If user typed a location (e.g. "Lawspet"), ask AI to find places near THAT.
    # 2. If no text, use GPS coordinates.
    # 3. If GPS is 0.0 (blocked), use City Name.

    location_context = ""
    if loc_name and loc_name != "Current Location":
        location_context = f"near '{loc_name}' in {dest['city']}"
    elif user_lat != 0.0:
        location_context = f"near coordinates {user_lat}, {user_lng}"
    else:
        location_context = f"in {dest['city']} (City Center)"

    prompt = f"""
    I am looking for "{category}" locations {location_context}.
    City Context: {dest['city']}, {dest['country']}.

    CRITICAL INSTRUCTIONS:
    1. List 5 REAL, EXISTING places matching the category.
    2. Search strictly within 15 km of the requested location.
    3. Provide ACCURATE Latitude/Longitude for mapping.
    
    Return STRICT JSON:
    {{
        "results": [
            {{ "name": "Place Name", "lat": 12.345, "lng": 67.890, "address": "Short Address" }}
        ]
    }}
    """
    data = get_gemini_json(prompt)
    
    if data is None:
        places = []
    else:
        places = data.get('results', [])
    
    return render_template('emergency/nearby_results.html', 
                           category=category, 
                           user_lat=user_lat, 
                           user_lng=user_lng,
                           current_loc_name=loc_name,
                           places=places)
@app.route('/map-view')
def map_view():
    # Simple page to show a single pin
    name = request.args.get('name')
    lat = request.args.get('lat')
    lng = request.args.get('lng')
    return render_template('common/map_view.html', name=name, lat=lat, lng=lng)

@app.route('/map')
def map_page():
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    return render_template('home/map.html', destination=dest)

# --- CHATBOT ROUTES ---

@app.route('/chat')
def chat_page():
    if 'user_id' not in session: return redirect(url_for('login'))
    return render_template('chat/index.html')

@app.route('/api/chat', methods=['POST'])
def chat_api():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    
    user_msg = request.json.get('message')
    dest = session.get('current_destination')
    
    # Context-Aware Prompt
    system_instruction = f"""
    You are CityPal, a smart local travel guide for {dest['city']}, {dest['country']}.
    User is currently in {dest['city']}.
    
    Rules:
    1. Keep answers SHORT (max 2-3 sentences).
    2. Be specific to {dest['city']}.
    3. Use emojis where helpful.
    4. If asked about emergency, suggest calling 100 or 108.
    """
    
    try:
        # We ask for plain text response here, not JSON
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=f"{system_instruction}\n\nUser Question: {user_msg}"
        )
        ai_reply = response.text
    except Exception as e:
        ai_reply = "I'm having trouble connecting right now. Try again?"

    return jsonify({"reply": ai_reply})

# --- PROFILE & SETTINGS ROUTES ---

@app.route('/profile')
def profile_page():
    if 'user_id' not in session: return redirect(url_for('login'))
    user = mongo.db.users.find_one({'_id': ObjectId(session['user_id'])})
    return render_template('profile/index.html', user=user)

@app.route('/delete-account', methods=['POST'])
def delete_account():
    if 'user_id' not in session: return jsonify({"error": "Unauthorized"}), 401
    
    # In a real app, you would delete the user from MongoDB here
    # mongo.db.users.delete_one({'_id': ObjectId(session['user_id'])})
    
    session.clear()
    flash('Your account has been deleted.', 'info')
    return redirect(url_for('register_page'))

# --- EDIT PROFILE ROUTES ---

@app.route('/profile/edit', methods=['GET', 'POST'])
def edit_profile():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    user = mongo.db.users.find_one({'_id': ObjectId(session['user_id'])})
    
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        
        update_data = {
            'full_name': full_name,
            'email': email
        }
        
        # Only update password if the user typed a new one
        if password and len(password) > 0:
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
            update_data['password'] = hashed_password
            
        mongo.db.users.update_one({'_id': ObjectId(session['user_id'])}, {'$set': update_data})
        
        # Update session info
        session['user_email'] = email
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile_page'))

    return render_template('profile/edit.html', user=user)

# --- ADD THESE ROUTES TO app.py ---

@app.route('/essentials/sim-card')
def sim_hub():
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # 1. Check if user clicked Tourist or Resident (Defaults to tourist)
    user_type = request.args.get('user_type', 'tourist')

    # 2. Tell AI to generate content specifically for that user type
    prompt = f"""
    Act as a tech-savvy telecommunications guide for {dest['city']}, {dest['country']}.
    Summarize the current situation for obtaining SIM cards specifically for {user_type.upper()}S.

    Return STRICT JSON with this structure:
    {{
        "esim": {{
            "title": "Instant eSIM (Digital)",
            "desc": "Short 1-sentence summary tailored for a {user_type}.",
            "pros": ["Pro 1", "Pro 2"]
        }},
        "physical": {{
            "title": "Physical SIM",
            "desc": "Short 1-sentence summary tailored for a {user_type}.",
            "pros": ["Pro 1", "Pro 2"]
        }},
        "tips": [
            "Tip 1 specifically about documentation needed for a {user_type} (e.g., Passport vs Local ID).",
            "Tip 2 about network coverage."
        ]
    }}
    """
    data = get_gemini_json(prompt)
    
    content = data if data else {
        "esim": {"title": "Instant eSIM", "desc": "Digital SIM, instant activation.", "pros": []},
        "physical": {"title": "Physical SIM", "desc": "Traditional card, requires ID.", "pros": []},
        "tips": ["Documentation rules apply."]
    }

    # Pass the user_type to the HTML so we know which button to highlight
    return render_template('essentials/sim_hub.html', dest=dest, content=content, user_type=user_type)


@app.route('/essentials/sim-card/<sim_type>')
def sim_plans(sim_type):
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')

    # 1. Get User Location (Safe Float Conversion)
    try:
        user_lat = float(request.args.get('lat', 0.0))
        user_lng = float(request.args.get('lng', 0.0))
    except ValueError:
        user_lat, user_lng = 0.0, 0.0

    # 2. Define Context
    is_esim = (sim_type == 'esim')
    type_text = "eSIM (Digital)" if is_esim else "Physical SIM Card"
    
    print(f"\n📡 FETCHING PLANS: {type_text} in {dest['city']}...")

    # 3. STRICT API PROMPT (Removed "Act as guide")
    prompt = f"""
    You are a Data Retrieval API. 
    Context: User is in {dest['city']}, {dest['country']}. 
    Request: {type_text} providers and purchase locations.

    INSTRUCTIONS:
    1. Identify 3 major mobile operators in {dest['country']} suitable for tourists.
    2. Identify 4 REAL places in {dest['city']} to buy/activate this SIM.
       - If Physical SIM: Find "Mobile Store", "{dest['city']} Airport Kiosk", or specific Carrier Stores.
       - If eSIM: Find "Free Wifi Spots" (Cafes/Malls) in {dest['city']} where users can download the eSIM profile.
    3. Generate ACCURATE Latitude/Longitude for these 4 places.

    OUTPUT FORMAT:
    Return ONLY raw JSON. No markdown. No conversational text.
    {{
        "providers": [
            {{ "name": "Operator Name", "tag": "Best for X", "desc": "1-sentence reason." }}
        ],
        "locations": [
            {{
                "name": "Store/Place Name",
                "type": "Store", 
                "address": "Street Name, {dest['city']}", 
                "lat": 12.3456, 
                "lng": 78.9101
            }}
        ]
    }}
    """
    
    # 4. Fetch & Parse
    data = get_gemini_json(prompt)
    
    # 5. Handle Results
    providers = []
    locations = []
    
    if data:
        providers = data.get('providers', [])
        locations = data.get('locations', [])
        print(f"✅ Success: Found {len(providers)} providers and {len(locations)} locations.")
    else:
        print("❌ AI Failed to return JSON. Check server logs.")

    # 6. Render
    return render_template('essentials/sim_plans.html', 
                           sim_type=sim_type.title(),
                           providers=providers,
                           places=locations,
                           dest=dest,
                           user_lat=user_lat,
                           user_lng=user_lng)

# --- ADD THIS TO app.py ---

# --- 1. TRANSPORT CARDS (Linked from Home Page "Essential Info") ---
# --- 1. TRANSPORT MENU (Linked from Home Page "Essentials") ---
@app.route('/transport')
def transport_card_menu():
    """
    Shows the IC Card / QR Pass / Taxi Menu with Tourist/Resident toggle.
    """
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # 1. Check if user clicked Tourist or Resident (Defaults to tourist)
    user_type = request.args.get('user_type', 'tourist')

    # 2. Tell AI to generate content specifically for that user type
    prompt = f"""
    Act as a local transport guide for {dest['city']}, {dest['country']}.
    Summarize the best public transport payment options specifically for {user_type.upper()}S.

    Return STRICT JSON with this structure:
    {{
        "ic_card": {{
            "desc": "Short 1-2 sentence summary of why a {user_type} should use a physical rechargeable transit card here."
        }},
        "qr_pass": {{
            "desc": "Short 1-2 sentence summary of why a {user_type} should use mobile/QR tickets or day passes."
        }},
        "taxi_apps": {{
            "desc": "Short 1-2 sentence summary of ride-hailing app usage tailored for a {user_type}."
        }},
        "tips": [
            "Tip 1 about transport payments or passes specifically tailored for a {user_type}.",
            "Tip 2 about navigating the transport system."
        ]
    }}
    """
    data = get_gemini_json(prompt)
    
    # Fallback if AI fails
    content = data if data else {
        "ic_card": {"desc": "Best for long stays. Tap-and-go on trains, buses, and convenience stores."},
        "qr_pass": {"desc": "Best for short trips. Unlimited rides on subways/metros."},
        "taxi_apps": {"desc": "Uber, Grab, or local equivalents. Best for luggage or late nights."},
        "tips": ["Always check if passes cover all local transit lines."]
    }

    return render_template('transport/menu.html', destination=dest, content=content, user_type=user_type)


# --- 2. TRANSPORT ROUTE PLANNER (Linked from Footer "Transport") ---
@app.route('/transport-hub')
def transport_route_planner():
    """
    Shows the Replit-style Route Planner (Bus/Metro/Taxi).
    """
    if 'user_id' not in session: return redirect(url_for('login'))
    dest = session.get('current_destination')
    
    # Get user coordinates
    user_lat = request.args.get('lat', 0.0)
    user_lng = request.args.get('lng', 0.0)

    # Note: Ensure you have a template named 'transport/routes.html' or similar 
    # if 'transport/hub.html' is used for cards. 
    # Based on your previous request, I will assume you want the Route Planner 
    # to use 'transport/route_planner.html' to avoid file conflicts too.
    return render_template('transport/route_planner.html', 
                           dest=dest, 
                           user_lat=user_lat, 
                           user_lng=user_lng)

@app.route('/api/transport-search', methods=['POST'])
def transport_search_api():
    data = request.json
    origin = data.get('origin', 'Current Location')
    destination = data.get('destination')
    
    # 1. Get destination and currency symbol from session
    dest = session.get('current_destination', {})
    city = dest.get('city', data.get('city', 'Unknown'))
    country = dest.get('country', 'Unknown')
    currency_symbol = dest.get('currency_symbol', '$')
    
    lat = data.get('lat')
    lng = data.get('lng')
    
    origin_context = origin
    if lat and lng and origin in ["My Current Location", "User Location", "Current Location"]:
        origin_context = f"GPS Coordinates ({lat}, {lng})"

    # 2. Add currency instruction to the prompt
    prompt = f"""
    Act as a Multi-Modal Transport Planner for {city}, {country}.
    
    TRIP DETAILS:
    - FROM: {origin_context}
    - TO: {destination}

    CRITICAL INSTRUCTION FOR PRICE:
    You MUST use the local currency symbol ({currency_symbol}) for all prices.
    Example formats: "{currency_symbol}20", "{currency_symbol}150 - {currency_symbol}200".
    Do NOT use '₹' unless the local currency is actually Indian Rupees.

    INSTRUCTIONS:
    1. Determine if this is a LOCAL trip (within one city) or INTER-CITY trip.
    2. Suggest 3 distinct transport options suitable for this specific route.
    
    CRITICAL: Return JSON strictly in this format:
    {{
        "routes": [
            {{
                "type": "Bus", 
                "name": "Local Transit", 
                "tag": "Economical", 
                "tag_color": "success",
                "duration": "30 mins", 
                "price": "{currency_symbol}20",
                "icon": "fas fa-bus",
                "desc": "Direct route from start to destination."
            }}
        ]
    }}
    """
    
    try:
        ai_data = get_gemini_json(prompt)
        return jsonify(ai_data if ai_data else {"routes": []})
    except Exception as e:
        print("Transport Search Error:", e)
        return jsonify({"routes": []})
# --- ABOUT & PRIVACY ROUTES ---

@app.route('/profile/about')
def about_app():
    if 'user_id' not in session: return redirect(url_for('login'))
    return render_template('profile/about.html')

@app.route('/profile/privacy')
def privacy_policy():
    if 'user_id' not in session: return redirect(url_for('login'))
    return render_template('profile/privacy.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000)